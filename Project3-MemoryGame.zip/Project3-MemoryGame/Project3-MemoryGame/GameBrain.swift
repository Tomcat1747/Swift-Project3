//
//  GameBrain.swift
//  Project3-MemoryGame
//
//  Created by user149827 on 4/29/19.
//  Copyright © 2019 Thomas Bischoff. All rights reserved.
//

import Foundation

// Brain of the Memory Match Game
class GameBrain
{
    // Number of Moves that the Player has Currently Left
    var brainMovesLeft:String
    // Number of Moves that the Player has Currently Made
    var brainMovesMade:String
    // 2D Array of Tags
    var brainTags:[[Int]]
    // 2D Array of Emojis
    var brainEmojis:[[String]]
    // Number of Matches
    var matches: Int
    // Array of Flip Cards
    var isFlipped: [Bool]
    
    // Initializes the Values of the Game
    init()
    {
        // Set the Starting Number of Moves Left to be 20
        brainMovesLeft = "20"
        // Set the Starting Number of Moves Made to be 0
        brainMovesMade = "0"
        // Set the Size of Array of Tag to be Filled with Zeroes
        brainTags = Array(repeating: Array(repeating: 0, count: 4), count: 5)
        // Set the Size of Array of Emojis to be Filled with Blank Spaces
        brainEmojis = Array(repeating: Array(repeating: "", count: 4), count: 5)
        // Set the Number of Matches to be Zero
        matches = 0
        isFlipped = Array(repeating: false, count: 20)
    }
    // Loads a 4X5 2D Array with Sets of Emojis
    func createEmojiArray()->[[String]]
    {
        // Create an Empty 2D Array to Store the Emojis
        var array2D = [[String]]()
        // Set the Size of the Array
        array2D = Array(repeating: Array(repeating: "", count: 4), count: 5)
        // Create an Array of 10 Different Couples of Emojis
        var array = ["🐶","🐶","🐱","🐱","🐭","🐭","🐹","🐹","🐰","🐰","🦊","🦊","🐻","🐻","🐼","🐼","🐨","🐨","🐯","🐯"]
        // Go Through the X-Axis Rows of Cards
        for i in 0...4
        {
            // Go Through the Y-Axis Columns of Cards
            for j in 0...3
            {
                // Find What One Minus the Current Count of the Emoji Array is
                let lastIndex = array.count - 1
                // Get a Random Integer Between Zero and the Last Index in the Array
                let index = Int.random(in: 0...lastIndex)
                // Add the Emoji from that Index into the 2D Array
                array2D[i][j] = array[index]
                // Remove the Used Index from the Array
                array.remove(at: index)
            }
        }
        // Return the Array of Emojis
        return array2D
    }
    // Creates a 4X5 2D Array with the Tags of the Cards
    func getTagsOfCards()->[[Int]]
    {
        // Create an Empty 2D Array to Store the Tags
        var array2D = [[Int]]()
        // Set the Size of the Array
        array2D = Array(repeating: Array(repeating: 0, count: 4), count: 5)
        // Make the Starting Tag 100
        var tag = 100
        // Go Through the X-Axis Row of Cards
        for i in 0...4
        {
            // Go Through the Y-Axis Column of Cards
            for j in 0...3
            {
                // Add the Current Tag into the 2D Array
                array2D[i][j] = tag
                // Increment the Tag by One
                tag = tag + 1
            }
        }
        // Return the Array of Tags
        return array2D
    }
    // Finds the Emoji Located at the Given Tag
    func getEmoji(tag:Int)->String
    {
        // Get the Position of the Tag in the 2D Array
        let tagLocation = getTagLocation(tag: tag)
        // Check if the Location of the Tag is (-1,-1)
        if tagLocation == (-1,-1)
        {
            // Return That the Tag Does Not Exist
            return "No Emoji or Tag Could be Found"
        }
            // Otherwise
        else
        {
            // Get the Position on the X-Axis
            let x = tagLocation.0
            // Get the Postion on the Y-Axis
            let y = tagLocation.1
            // Get the Emoji from the 2D Array
            let emoji = brainEmojis[x][y]
            // Return the Emoji
            return emoji
        }
    }
    // Find the Position of a Tag in a 2D Array
    func getTagLocation(tag:Int)->(Int,Int)
    {
        // Go Through the X-Axis Rows of Cards
        for i in 0...4
        {
            // Go Through the Y-Axis Columns of Cards
            for j in 0...3
            {
                // Check if you Found the Tag You are Looking for
                if brainTags[i][j] == tag
                {
                    // Return the Tuple of the Holding the X and Y Position in the Array
                    return (i, j)
                }
            }
        }
        // If the Tag is Never Found Return Two Negative Ones
        return (-1,-1)
    }
    // Checks if Two Selected Tags Have Matching Emojis
    func cardsMatch(tag1:Int,tag2:Int)->Bool
    {
        // Check if the Two Tags are the Same
        if tag1 == tag2
        {
            // Return False, Since it is the Same Card Twice
            return false
        }
            // Otherwise
        else
        {
            // Get the Emoji from Tag1
            let emoji1 = getEmoji(tag: tag1)
            // Get the Emoji from Tag2
            let emoji2 = getEmoji(tag: tag2)
            // Check if the Two Emojis are the Same
            if emoji1 == emoji2
            {
                // Increase the Number of Matches by One
                matches = matches + 1
                // Return True, Since the Emojis are the Same
                return true
            }
                // Otherwise
            else
            {
                // Return False, Since the Emojis are Not the Same
                return false
            }
        }
    }
    // Sets and Returns the Array of Tags
    func setTags()->[[Int]]
    {
        // Set the Array of Tags
        brainTags = getTagsOfCards()
        // Return the Tags
        return brainTags
    }
    // Sets and Return the Array of Emojis
    func setEmojis()->[[String]]
    {
        // Set the Array of Emojis
        brainEmojis = createEmojiArray()
        // Return the Emojis
        return brainEmojis
    }
    
    // Increments the Number of Moves Made
    func incrementMoves()
    {
        // Integer Value of Moves Left
        let left = Int(brainMovesLeft)! - 1
        // Integer Value of Moves Made
        let made = Int(brainMovesMade)! + 1
        // Update the Moves Left
        brainMovesLeft = String(left)
        // Update the Moves Made
        brainMovesMade = String(made)
    }
    // Changes if the Card has Been Flipped
    func updateCard(index:Int)
    {
        // Check if the Card is Not Flipped
        if(isFlipped[index] == false)
        {
            // Set the Card is Flipped
            isFlipped[index] = true
        }
        // Otherwise
        else
        {
            // Set that Card is Not Flipped
            isFlipped[index] = false
        }
    }
}
