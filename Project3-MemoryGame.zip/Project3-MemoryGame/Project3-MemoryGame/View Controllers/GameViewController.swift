//
//  GameViewController.swift
//  Project3-MemoryGame
//
//  Created by user149827 on 4/25/19.
//  Copyright © 2019 Thomas Bischoff. All rights reserved.
// Button Images https://www.freepik.com/free-photos-vectors/background

import UIKit

class GameViewController: UIViewController {
    // Brain of the Game
    var myBrain = GameBrain()
    // Collection of Tags
    var tags = Array(repeating: Array(repeating: 0, count: 4), count: 5)
    // Collection of Emojis
    var emojis = Array(repeating: Array(repeating: "", count: 4), count: 5)
    // Array of Cards Being Used
    var activeCards = [UIButton]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Fill the Array with the Correct Tags
        tags = myBrain.setTags()
        // Fill Out the Array with Emojis
        emojis = myBrain.setEmojis()
        // Display the Number of Moves Left as 20
        movesLeft.text = myBrain.brainMovesLeft
        // Display the Number of Moves Made as 0
        movesMade.text = myBrain.brainMovesMade
        // Create a UI Alert Controller
        let startNotification = UIAlertController(title: "Welcome to Memory Match", message: "You will have 20 moves to match the 10 pairs of emojis.", preferredStyle: .alert)
        // Add the Dismiss Button
        startNotification.addAction(UIAlertAction(title: "Begin", style: .default))
        // Display the Alert
        self.present(startNotification, animated: true, completion: nil)
    }
    
    // Label for the Number of Moves Left
    @IBOutlet weak var lblMovesLeft: UILabel!
    // Count of the Number of Moves Left
    @IBOutlet weak var movesLeft: UILabel!
    // Label for the Number of Moves Made
    @IBOutlet weak var lblMovesMade: UILabel!
    // Count of the Number of Moves Made
    @IBOutlet weak var movesMade: UILabel!
    // Runs When a Player Clicks on One of the Cards
    @IBAction func btnCards(_ sender: UIButton)
    {
        // Check if the Array of Active Cards Holds the Selected Card
        if activeCards.contains(sender)
        {
            // Exit Out of the Function
            return
        }
        // Check if the Array of Active Cards is Empty
        else if activeCards.isEmpty || activeCards.count == 1
        {
            // Add the Card into the Active Array
            activeCards.append(sender)
            // Flip the Card
            flipCard(card: sender)
            // Check if the Array Has a Count of 2
            if activeCards.count == 2
            {
                // Get the Tag of the First Card
                guard let tag1 = activeCards.first?.tag else { return  }
                // Get the Tag of the Second Card
                guard let tag2 = activeCards.last?.tag else { return }
                // Check if the Player Got a Match
                if (myBrain.cardsMatch(tag1: tag1, tag2: tag2))
                {
                    // Disable the First Card
                    disableCard(card: (activeCards.first)!)
                    // Disable the Second Card
                    disableCard(card: (activeCards.last)!)
                }
                // Otherwise
                else
                {
                    
                }
                // Increment the Number of Moves
                myBrain.incrementMoves()
                // Check if the Number of Moves Left is Equal to 5
                if myBrain.brainMovesLeft == "5"
                {
                    // Change the Color of the Font to be Red
                    changeColor()
                }
                // Check if the Game is Over
                gameOver()
                // Update the Number of Moves Left
                movesLeft.text = myBrain.brainMovesLeft
                // Update the Number of Moves Made
                movesMade.text = myBrain.brainMovesMade
            }
        }
        // Otherwise
        else
        {
            // Flip the Cards Back Over
            flipCard(card: activeCards.first!)
            flipCard(card: activeCards.last!)
            // Empty the Array of Active Cards
            activeCards.removeAll()
            // Append the Card to the Newly Emptied Array
            activeCards.append(sender)
            // Flip the Card
            flipCard(card: sender)
        }
    }
    // Change the Color of the Moves Left and Moves Made to be Red
    func changeColor()
    {
        // Change the Label of the Number of Moves Left to be Red
        lblMovesLeft.textColor = UIColor.red
        // Change the Count of the Moves Left to be Red
        movesLeft.textColor = UIColor.red
        // Change the Label of the Number of Moves Made to be Red
        lblMovesMade.textColor = UIColor.red
        // Change the COunt of the Moves Made to be Red
        movesMade.textColor = UIColor.red
    }
    // Flips a Card
    func flipCard(card:UIButton)
    {
        // Holds the Text Being Displayed on the Card
        var cardLabel: String
        // Holds the Image that is Being Displayed on the Card
        var cardImage: UIImage
        // Get the Index of the Button
        let index = card.tag - 100
        // Check if the Card Label is Not Blank
        if myBrain.isFlipped[index]
        {
            // Set the Background of the Card
            cardImage = (UIImage(named: "242.jpg") as UIImage?)!
            // Set the Label to be Blank
            cardLabel = ""
        }
        // Otherwise
        else
        {
            // Set the Image of the Card to be Blank
            cardImage = UIImage()
            // Set the Label to Display the Emoji on the Card
            cardLabel = myBrain.getEmoji(tag: card.tag)
        }
        // Update the Card
        myBrain.updateCard(index: index)
        // Display the Label on the Card
        card.setTitle(cardLabel, for: UIControl.State.normal)
        // Display the Background of the Card
        card.setBackgroundImage(cardImage, for: UIControl.State.normal)
    }
    // Disables a Card
    func disableCard(card: UIButton)
    {
        // Set the Card to Display a Checkmark
        card.setTitle("✔︎", for: UIControl.State.normal)
        // Disable the Button
        card.isEnabled = false
    }
    // Runs to Check if the Game is Over
    func gameOver()
    {
        // Check if the Number of Turns Left is 0
        if myBrain.brainMovesLeft == "0"
        {
            // Create a UI Alert Controller
            let startNotification = UIAlertController(title: "Game Over", message: "You matched " +  String(myBrain.matches) + " pairs out of 10.", preferredStyle: .alert)
            // Add the Dismiss Button
            startNotification.addAction(UIAlertAction(title: "Return to Menu", style: .default))
            // Display the Alert
            self.present(startNotification, animated: true, completion: nil)
        }
        // Check if the Number of Matches is 10
        else if myBrain.matches == 10
        {
            // Create a UI Alert Controller
            let startNotification = UIAlertController(title: "You Win", message: "Congratulations you have matched all 10 pairs of cards!", preferredStyle: .alert)
            // Add the Dismiss Button
            startNotification.addAction(UIAlertAction(title: "Return to Menu", style: .default))
            // Display the Alert
            self.present(startNotification, animated: true, completion: nil)
        }
        // Otherwise
        else
        {
            // Exit the Function
            return
        }
        // Transition to the Main Menu
        performSegue(withIdentifier: "Return to Menu", sender: nil)
    }
}
