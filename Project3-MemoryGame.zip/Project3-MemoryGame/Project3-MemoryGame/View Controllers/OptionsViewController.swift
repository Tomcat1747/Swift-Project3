//
//  OptionsViewController.swift
//  Project3-MemoryGame
//
//  Created by user149827 on 5/2/19.
//  Copyright © 2019 Thomas Bischoff. All rights reserved.
//

import UIKit

class OptionsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    
    
    
    
    
    
    
    
    
    // The View of the Options Screen
    @IBOutlet var optionsView: UIView!
    // Toggles On and Off Night Mode
    @IBAction func btnNightMode(_ sender: UIButton)
    {
        
    }
}
